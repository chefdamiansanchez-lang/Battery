package com.datco.saludbateria

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class BatteryAlertService : Service() {

    private var notified = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            evaluar(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        crearCanales()
        val n = notificacionFija()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_FIJA, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_FIJA, n)
        }
        val sticky = ContextCompat.registerReceiver(
            this,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        if (sticky != null) evaluar(sticky)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    private fun evaluar(i: Intent) {
        if (!Prefs.enabled(this)) {
            stopSelf()
            return
        }
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        val pct = level * 100 / scale
        val enchufado = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val limite = Prefs.threshold(this)

        if (enchufado && pct >= limite) {
            if (!notified) {
                notified = true
                avisar(pct)
            }
        } else {
            notified = false
        }
    }

    private fun avisar(pct: Int) {
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_ALERTA)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setContentTitle("Batería al $pct %")
            .setContentText("Llegó a tu límite de carga. Podés desconectar el cargador.")
            .setContentIntent(abrir)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        getSystemService(NotificationManager::class.java).notify(ID_ALERTA, n)
    }

    private fun notificacionFija() = NotificationCompat.Builder(this, CH_FIJA)
        .setSmallIcon(R.drawable.ic_stat_bolt)
        .setContentTitle("Salud Batería")
        .setContentText("Vigilando la carga de tu batería")
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    private fun crearCanales() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_FIJA, "Vigilancia de carga", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTA, "Alerta de carga", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    companion object {
        private const val CH_FIJA = "vigilancia"
        private const val CH_ALERTA = "alerta"
        private const val ID_FIJA = 1
        private const val ID_ALERTA = 2

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, BatteryAlertService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, BatteryAlertService::class.java))
        }
    }
}

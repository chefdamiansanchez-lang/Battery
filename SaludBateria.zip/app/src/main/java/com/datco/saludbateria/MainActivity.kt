package com.datco.saludbateria

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private val VERDE = Color(0xFF3DDC84)
private val CARD = Color(0xFF161C21)
private val GRIS = Color(0xFF8A9199)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        if (Prefs.enabled(this)) BatteryAlertService.start(this)
        setContent { App() }
    }
}

@Composable
fun App() {
    var splash by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = VERDE)) {
        Crossfade(targetState = splash, animationSpec = tween(500), label = "raiz") { mostrando ->
            if (mostrando) DatcoSplash { splash = false } else HomeScreen()
        }
    }
}

// ---------------- Splash DATCO ----------------
@Composable
fun DatcoSplash(onDone: () -> Unit) {
    val alfa = remember { Animatable(0f) }
    val escala = remember { Animatable(0.8f) }
    LaunchedEffect(Unit) {
        launch { alfa.animateTo(1f, tween(800)) }
        launch { escala.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) }
        delay(2300)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.alpha(alfa.value).scale(escala.value)
        ) {
            Box(
                Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "DATCO",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 10.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF8FA3B5),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF6B7C8C),
            fontSize = 13.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 56.dp)
                .alpha(alfa.value)
        )
    }
}

// ---------------- Pantalla principal ----------------
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<BatteryInfo?>(null) }

    DisposableEffect(Unit) {
        val receptor = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                info = BatteryReader.read(c, i)
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receptor, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        if (sticky != null) info = BatteryReader.read(ctx, sticky)
        onDispose { ctx.unregisterReceiver(receptor) }
    }

    var alertaOn by remember { mutableStateOf(Prefs.enabled(ctx)) }
    var limite by remember { mutableIntStateOf(Prefs.threshold(ctx)) }
    val permiso = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0B2016), Color(0xFF0E1216), Color(0xFF0E1216)))
            )
    ) {
        val d = info
        if (d != null) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡", color = VERDE, fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("Salud Batería", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(24.dp))

                val colorNivel = when {
                    d.percent <= 15 -> Color(0xFFFF5252)
                    d.percent <= 30 -> Color(0xFFFFA726)
                    else -> VERDE
                }
                val estado = when {
                    d.full -> "Completa"
                    d.charging -> "Cargando"
                    else -> "Sin cargar"
                }
                Gauge(d.percent, estado, colorNivel)
                Spacer(Modifier.height(24.dp))

                // Tiempo de carga
                val tiempo = when {
                    d.full -> "Completa"
                    d.charging -> formatoTiempo(d.chargeTimeMs)
                    else -> "—"
                }
                val tiempoDetalle = when {
                    d.full -> "La batería está al 100 %"
                    d.charging -> "Hasta la carga completa"
                    else -> "Conectá el cargador para ver el tiempo"
                }
                InfoCard("Tiempo de carga", "⏱", tiempo, tiempoDetalle, Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InfoCard(
                        "Salud", "♥",
                        d.healthPercent?.let { "$it %" } ?: d.healthLabel,
                        if (d.healthPercent != null) d.healthLabel else "",
                        Modifier.weight(1f).fillMaxHeight()
                    )
                    InfoCard(
                        "Temperatura", "🌡",
                        String.format(Locale("es", "AR"), "%.1f °C", d.tempC),
                        etiquetaTemp(d.tempC),
                        Modifier.weight(1f).fillMaxHeight()
                    )
                }
                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InfoCard(
                        "Voltaje", "⚡",
                        String.format(Locale("es", "AR"), "%.2f V", d.voltageV), "",
                        Modifier.weight(1f).fillMaxHeight()
                    )
                    InfoCard(
                        "Tecnología", "▣", d.technology, "",
                        Modifier.weight(1f).fillMaxHeight()
                    )
                }
                Spacer(Modifier.height(12.dp))

                InfoCard(
                    "Ciclos de carga", "↻",
                    d.cycles?.toString() ?: "No disponible",
                    if (d.cycles == null) "Tu equipo no informa este dato" else "Ciclos acumulados",
                    Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))

                // Alerta de carga
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(CARD)
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Alerta de carga", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("Avisar al llegar al $limite %", color = GRIS, fontSize = 13.sp)
                        }
                        Switch(
                            checked = alertaOn,
                            onCheckedChange = { on ->
                                alertaOn = on
                                Prefs.setEnabled(ctx, on)
                                if (on) {
                                    if (Build.VERSION.SDK_INT >= 33 &&
                                        ContextCompat.checkSelfPermission(
                                            ctx, Manifest.permission.POST_NOTIFICATIONS
                                        ) != PackageManager.PERMISSION_GRANTED
                                    ) {
                                        permiso.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    BatteryAlertService.start(ctx)
                                } else {
                                    BatteryAlertService.stop(ctx)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = VERDE,
                                checkedThumbColor = Color(0xFF0E1216)
                            )
                        )
                    }
                    Slider(
                        value = limite.toFloat(),
                        onValueChange = { limite = it.roundToInt() },
                        onValueChangeFinished = { Prefs.setThreshold(ctx, limite) },
                        valueRange = 50f..100f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = VERDE,
                            activeTrackColor = VERDE,
                            inactiveTrackColor = Color(0xFF2A3138)
                        )
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun Gauge(percent: Int, estado: String, color: Color) {
    val progreso by animateFloatAsState(percent / 100f, tween(900), label = "gauge")
    Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val grosor = 26.dp.toPx()
            val mitad = grosor / 2
            val tam = Size(size.width - grosor, size.height - grosor)
            drawArc(
                color = Color(0xFF1B3A28),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(mitad, mitad),
                size = tam,
                style = Stroke(width = grosor)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * progreso,
                useCenter = false,
                topLeft = Offset(mitad, mitad),
                size = tam,
                style = Stroke(width = grosor, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$percent%", color = color, fontSize = 54.sp, fontWeight = FontWeight.Bold)
            Text(estado, color = Color(0xFFB5BDC4), fontSize = 14.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun InfoCard(titulo: String, icono: String, valor: String, detalle: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(CARD)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1C3A2A)),
                contentAlignment = Alignment.Center
            ) {
                Text(icono, fontSize = 16.sp, color = VERDE)
            }
            Spacer(Modifier.width(10.dp))
            Text(titulo, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(12.dp))
        Text(valor, color = VERDE, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (detalle.isNotEmpty()) {
            Text(detalle, color = GRIS, fontSize = 13.sp)
        }
    }
}

private fun formatoTiempo(ms: Long): String {
    if (ms <= 0) return "Calculando…"
    val min = ms / 60000
    val h = min / 60
    val m = min % 60
    return if (h > 0) "$h h $m min" else "$m min"
}

private fun etiquetaTemp(t: Float): String = when {
    t < 15f -> "Fría"
    t <= 35f -> "Normal"
    t <= 40f -> "Tibia"
    t < 45f -> "Alta"
    else -> "Muy alta"
}
